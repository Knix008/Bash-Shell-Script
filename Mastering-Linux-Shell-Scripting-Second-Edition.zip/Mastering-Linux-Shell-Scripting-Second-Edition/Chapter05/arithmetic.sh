#!/bin/bash
a=$(( 2 + 3 ))
echo $a