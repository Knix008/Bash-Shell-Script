#!/bin/bash
myarr=(one two three four five)
unset myarr[1] #This will remove the second element
unset myarr    #This will remove all elements