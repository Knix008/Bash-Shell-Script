#!/bin/bash
#Author: @likegeeks
if [ -z "mokhtar" ] 
then
echo "String length is zero"
else
echo "String length is not zero"
fi
