#!/bin/bash
#Author: @likegeeks
if [ -n "mokhtar" ] 
then
echo "String length is greater than zero"
else
echo "String is zero length"
fi
