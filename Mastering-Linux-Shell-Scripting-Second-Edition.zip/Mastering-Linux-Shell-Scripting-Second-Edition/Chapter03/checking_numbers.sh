#!/bin/bash
#Author: @likegeeks
if [ 12 -gt 10 ]
then
echo "number1 is greater than number2"
else
echo "number1 is less than number2"
fi
