#!/bin/bash
for (( v1 = 1; v1 <= 5; v1++ ))
do
echo "$v1"
done > file