#!/bin/bash
for var in one "This is two" "Now three" "We'll check four"
do
echo "Value: $var"
done